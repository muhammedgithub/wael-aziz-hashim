package com.wael.simplecalc;

import android.app.Application;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private EditText txtFN1, txtSN1;
    private  TextView lblResult1;
    private Button btnAdd1, btnSub1, btnMul1, btnDiv1  ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtFN1 = (EditText) findViewById(R.id.txtFN);
        txtSN1 = (EditText) findViewById(R.id.txtSN);
        lblResult1 = (TextView) findViewById(R.id.lbResult);
        btnAdd1 = (Button) findViewById(R.id.btnAdd);
        btnSub1 = (Button) findViewById(R.id.btnSub);
        btnMul1 = (Button) findViewById(R.id.btnMul);
        btnDiv1 = (Button) findViewById(R.id.btnDIV);


        btnAdd1.setOnClickListener(this);
        btnSub1.setOnClickListener(this);
        btnMul1.setOnClickListener(this);
        btnDiv1.setOnClickListener(this);

    }


    public  void addMethod(View v){

        int result= Integer.parseInt(txtFN1.getText().toString()) + Integer.parseInt(txtSN1.getText().toString()) ;

        lblResult1.setText( "The Result: " + result );
    }

/*
    public  void subMethod(View v){

        int result= Integer.parseInt(txtFN1.getText().toString()) - Integer.parseInt(txtSN1.getText().toString()) ;

        lblResult1.setText( "The Result: " + result );
    }

    public  void mulMethod(View v){

        int result= Integer.parseInt(txtFN1.getText().toString()) * Integer.parseInt(txtSN1.getText().toString()) ;

        lblResult1.setText( "The Result: " + result );
    }

    public  void divMethod(View v){

        if (Double.parseDouble(txtSN1.getText().toString()) !=  0 )
        {

        double result= Double.parseDouble(txtFN1.getText().toString()) / Double.parseDouble(txtSN1.getText().toString()) ;

        lblResult1.setText( "The Result: " + result );
    }else
        lblResult1.setText( "divide by zero");
    }

*/


    public void exitMethod(View v)
    {
        System.exit(0);
    }

    public void cleartMethod(View v)
    {
        txtFN1.setText("");
        txtSN1.setText("");
    }

    @Override
    public void onClick(View v) {

        double result =0;

        switch (v.getId()) {
            case R.id.btnAdd:
                 result = Double.parseDouble(txtFN1.getText().toString()) + Double.parseDouble(txtSN1.getText().toString());
                break;

            case R.id.btnSub:
                result =  Double.parseDouble(txtFN1.getText().toString()) -  Double.parseDouble(txtSN1.getText().toString());
                break;

            case R.id.btnMul:
                 result =  Double.parseDouble(txtFN1.getText().toString()) *  Double.parseDouble(txtSN1.getText().toString());
                break;

            case R.id.btnDIV:
                result =  Double.parseDouble(txtFN1.getText().toString()) /  Double.parseDouble(txtSN1.getText().toString());
                break;
            default:
                Toast.makeText(MainActivity.this,"Invalid Option", Toast.LENGTH_SHORT).show();
                break;


    }
        lblResult1.setText( "The Result:   " + result );


    }
}
